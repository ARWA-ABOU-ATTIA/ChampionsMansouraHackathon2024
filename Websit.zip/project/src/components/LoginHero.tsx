export function LoginHero() {
  return (
    <div className="relative h-full w-full">
      <img
        src="https://images.unsplash.com/photo-1521737711867-e3b97375f902?auto=format&fit=crop&q=80"
        alt="People collaborating"
        className="h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-black/20 flex items-end p-8">
        <p className="text-white text-lg leading-relaxed max-w-md" dir="rtl">
          كن أنت التغيير الذي تريد أن تراه في العالم نقدم
          إليك اليوم برنامج على تغيير حياة الآخرين من أول
          خطواتك لتصبح مستشار في مساعدة
          الآخرين لكي تصل صغير
        </p>
      </div>
    </div>
  );
}