import React from 'react';
import { Clock, ThumbsUp, MessageCircle } from 'lucide-react';

const posts = [
  {
    id: 1,
    title: "دليل المبتدئين للتطوير الشخصي",
    likes: 24,
    comments: 8,
    timeAgo: "منذ ساعتين",
  },
  {
    id: 2,
    title: "كيفية تحسين مهارات التواصل",
    likes: 18,
    comments: 5,
    timeAgo: "منذ 3 ساعات",
  },
  {
    id: 3,
    title: "نصائح للنجاح في العمل",
    likes: 32,
    comments: 12,
    timeAgo: "منذ 5 ساعات",
  },
];

export function PostsList() {
  return (
    <div className="space-y-4">
      {posts.map((post) => (
        <div key={post.id} className="p-4 bg-white rounded-lg shadow-sm">
          <h3 className="font-semibold mb-2" dir="rtl">{post.title}</h3>
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <ThumbsUp className="w-4 h-4" />
              <span>{post.likes}</span>
            </div>
            <div className="flex items-center gap-1">
              <MessageCircle className="w-4 h-4" />
              <span>{post.comments}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              <span dir="rtl">{post.timeAgo}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}