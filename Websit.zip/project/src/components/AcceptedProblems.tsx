import React from 'react';
import { CheckCircle2, Users, Calendar } from 'lucide-react';

const problems = [
  {
    id: 1,
    title: "صعوبة في التواصل مع الفريق",
    clientCount: 3,
    date: "15 مارس 2024",
    category: "مهارات تواصل",
  },
  {
    id: 2,
    title: "تحديات في إدارة الوقت",
    clientCount: 5,
    date: "12 مارس 2024",
    category: "تنظيم وقت",
  },
  {
    id: 3,
    title: "ضغط العمل والتوتر",
    clientCount: 4,
    date: "10 مارس 2024",
    category: "إدارة الضغط",
  },
];

export function AcceptedProblems() {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-semibold mb-4" dir="rtl">المشاكل المقبولة</h3>
      <div className="space-y-4">
        {problems.map((problem) => (
          <div key={problem.id} className="border-b border-gray-100 last:border-0 pb-4 last:pb-0">
            <div className="flex items-center gap-3 mb-2">
              <CheckCircle2 className="w-5 h-5 text-green-500" />
              <h4 className="font-medium" dir="rtl">{problem.title}</h4>
            </div>
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-1">
                <Users className="w-4 h-4" />
                <span dir="rtl">{problem.clientCount} عملاء</span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                <span dir="rtl">{problem.date}</span>
              </div>
              <span className="text-blue-600 bg-blue-50 px-2 py-1 rounded-full text-xs" dir="rtl">
                {problem.category}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}