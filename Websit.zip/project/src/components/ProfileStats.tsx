import React from 'react';

export function ProfileStats() {
  return (
    <div className="grid grid-cols-3 gap-4 p-6 bg-white rounded-lg shadow-sm">
      <div className="text-center">
        <div className="text-2xl font-bold text-blue-600">25</div>
        <div className="text-sm text-gray-600" dir="rtl">مشاهدات</div>
      </div>
      <div className="text-center">
        <div className="text-2xl font-bold text-blue-600">12</div>
        <div className="text-sm text-gray-600" dir="rtl">متابعات</div>
      </div>
      <div className="text-center">
        <div className="text-2xl font-bold text-blue-600">8</div>
        <div className="text-sm text-gray-600" dir="rtl">منشورات</div>
      </div>
    </div>
  );
}