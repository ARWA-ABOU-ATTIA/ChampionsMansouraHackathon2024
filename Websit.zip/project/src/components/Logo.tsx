import { Handshake } from 'lucide-react';

export function Logo() {
  return (
    <div className="flex items-center justify-center gap-2">
      <Handshake className="w-8 h-8 text-blue-600" />
      <span className="text-xl font-bold text-gray-800">TESLAM</span>
    </div>
  );
}