import React from 'react';
import { Star, Clock, CheckCircle } from 'lucide-react';

const tasks = [
  {
    id: 1,
    title: "تقديم المشورة في التطوير الشخصي",
    rating: 4.5,
    status: "مكتمل",
    timeAgo: "منذ يومين",
  },
  {
    id: 2,
    title: "جلسة استشارية في تطوير المهارات القيادية",
    rating: 5,
    status: "مكتمل",
    timeAgo: "منذ 3 أيام",
  },
  {
    id: 3,
    title: "تقديم حلول لتحديات العمل",
    rating: 4.8,
    status: "مكتمل",
    timeAgo: "منذ أسبوع",
  },
];

export function RecentTasks() {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold mb-4" dir="rtl">التقييمات الأخيرة</h3>
      {tasks.map((task) => (
        <div key={task.id} className="p-4 bg-white rounded-lg shadow-sm">
          <h4 className="font-semibold mb-2" dir="rtl">{task.title}</h4>
          <div className="flex items-center justify-between text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 text-yellow-400 fill-current" />
              <span>{task.rating}</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span dir="rtl">{task.status}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span dir="rtl">{task.timeAgo}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}