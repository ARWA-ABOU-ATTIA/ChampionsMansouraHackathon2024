import React from 'react';
import { ProfileHeader } from './ProfileHeader';
import { ProfileStats } from './ProfileStats';
import { ActivityChart } from './ActivityChart';
import { RecentTasks } from './RecentTasks';
import { AcceptedProblems } from './AcceptedProblems';

export function ProfilePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <ProfileHeader />
      
      <div className="max-w-4xl mx-auto p-6">
        <div className="flex items-center gap-6 mb-8">
          <div className="w-24 h-24 rounded-full overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80"
              alt="Profile"
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h2 className="text-2xl font-bold" dir="rtl">مرحبا اسم المستخدم</h2>
            <p className="text-gray-600" dir="rtl">مستشار تطوير شخصي</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <ProfileStats />
            <RecentTasks />
          </div>
          <div className="space-y-6">
            <ActivityChart />
            <AcceptedProblems />
          </div>
        </div>
      </div>
    </div>
  );
}