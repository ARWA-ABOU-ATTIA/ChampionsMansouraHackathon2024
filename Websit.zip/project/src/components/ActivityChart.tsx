import React from 'react';

export function ActivityChart() {
  const bars = [65, 45, 75, 50, 85];
  
  return (
    <div className="p-6 bg-white rounded-lg shadow-sm">
      <h3 className="text-lg font-semibold mb-4" dir="rtl">نشاطات أسبوعية</h3>
      <div className="flex items-end justify-between h-32 gap-2">
        {bars.map((height, index) => (
          <div
            key={index}
            className="w-full bg-blue-600 rounded-t-lg transition-all hover:bg-blue-700"
            style={{ height: `${height}%` }}
          />
        ))}
      </div>
    </div>
  );
}