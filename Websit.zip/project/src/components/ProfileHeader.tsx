import React from 'react';
import { Settings, Bell } from 'lucide-react';

export function ProfileHeader() {
  return (
    <div className="flex justify-between items-center p-6 border-b">
      <div className="flex items-center gap-4">
        <h1 className="text-xl font-bold" dir="rtl">صفحتك</h1>
      </div>
      <div className="flex items-center gap-4">
        <button className="p-2 hover:bg-gray-100 rounded-full">
          <Bell className="w-5 h-5" />
        </button>
        <button className="p-2 hover:bg-gray-100 rounded-full">
          <Settings className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}