import React, { useState } from 'react';
import { Logo } from './components/Logo';
import { AuthForm } from './components/AuthForm';
import { LoginHero } from './components/LoginHero';
import { ProfilePage } from './components/ProfilePage';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  if (isAuthenticated) {
    return <ProfilePage />;
  }

  return (
    <div className="flex h-screen">
      {/* Left Side - Form */}
      <div className="w-full lg:w-1/2 p-8 flex flex-col items-center justify-center bg-white">
        <div className="w-full max-w-md space-y-8">
          <Logo />
          <AuthForm onAuthenticated={() => setIsAuthenticated(true)} />
        </div>
      </div>

      {/* Right Side - Hero Image */}
      <div className="hidden lg:block lg:w-1/2">
        <LoginHero />
      </div>
    </div>
  );
}

export default App;